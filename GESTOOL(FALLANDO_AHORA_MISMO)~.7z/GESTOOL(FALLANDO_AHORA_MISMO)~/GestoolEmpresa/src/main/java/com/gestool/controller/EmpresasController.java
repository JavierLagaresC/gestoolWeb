package com.gestool.controller;

import com.gestool.ejb.EmpresasFacadeLocal;
import com.gestool.models.Empresas;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name = "empresasController")
@SessionScoped
public class EmpresasController implements Serializable{
    
    @EJB
    private EmpresasFacadeLocal empresaEJB;
    private List<Empresas> listaEmpresas;
    
    @PostConstruct
    public void init(){
       listaEmpresas = empresaEJB.findAll();
    }

    public List<Empresas> getListaEmpresas() {
        return listaEmpresas;
    }

    public void setListaEmpresas(List<Empresas> listaEmpresas) {
        this.listaEmpresas = listaEmpresas;
    }
    
    
}
