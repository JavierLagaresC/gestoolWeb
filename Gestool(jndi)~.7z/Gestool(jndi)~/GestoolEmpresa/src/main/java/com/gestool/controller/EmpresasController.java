package com.gestool.controller;

import com.gestool.ejb.EmpresasFacadeLocal;
import com.gestool.models.Empresas;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.faces.bean.SessionScoped;

@SessionScoped
@Named
public class EmpresasController implements Serializable{
    
    @EJB
    private Empresas empresas;
    @EJB
    private EmpresasFacadeLocal empresaEJB;
    @EJB
    private List<Empresas> listaEmpresas;
    
    @PostConstruct
    public void init(){
        empresas = new Empresas();
        listaEmpresas = empresaEJB.findAll();
    }

    public Empresas getEmpresas() {
        return empresas;
    }

    public void setEmpresas(Empresas empresas) {
        this.empresas = empresas;
    }

    
    
    public List<Empresas> getListaEmpresas() {
        return listaEmpresas;
    }

    public void setListaEmpresas(List<Empresas> listaEmpresas) {
        this.listaEmpresas = listaEmpresas;
    }
    
    public void nuevaEmpresa(){
        
        try{
            empresaEJB.create(empresas);
        }catch(Exception e){
            
        }
    }
}
